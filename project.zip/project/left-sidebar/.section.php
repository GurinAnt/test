<?
$sSectionName = "left-sidebar";
$arDirProperties = array(
   "type_sidebar" => "L"
);
?>