<?
$sSectionName = "Главная";
$arDirProperties = array(
   "title" => "Ex Machina by TEMPLATED",
   "robots" => "index, follow",
   "type_sidebar" => "H"
);
?>