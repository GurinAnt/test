<?
$MESS ['F_THEME_BEIGE'] = "Бежевый";
$MESS ['F_THEME_BLUE'] = "Голубой";
$MESS ['F_THEME_FLUXBB'] = "FluxBB";
$MESS ['F_THEME_GRAY'] = "Серый";
$MESS ['F_THEME_GREEN'] = "Зеленый";
$MESS ['F_THEME_ORANGE'] = "Оранжевый";
$MESS ['F_THEME_RED'] = "Красный";
$MESS ['F_THEME_WHITE'] = "Белый";
$MESS ['forum_template_name'] = "Форум (ЧПУ)";
$MESS ['forum_template_desc'] = "Страница с форумами в режиме ЧПУ";
$MESS ['forum_template_settings'] = "Настройки форумов";
$MESS ['forum_template_forums'] = "Показывать только выбранные форумы:";
$MESS ['forum_template_forums_all'] = "(все форумы)";
$MESS ['forum_template_theme'] = "Визуальная тема:";
$MESS ['forum_template_vote'] = "Настройки опросов на форуме";
$MESS ['forum_template_vote_enable'] = "Разрешить опросы:";
$MESS ['forum_template_vote_channel'] = "Группа опросов:";
$MESS ['forum_template_vote_channel_new'] = "Создать новую группу опросов";
$MESS ['forum_template_vote_channel_select'] = "Выбрать существующую группу";
$MESS ['forum_template_vote_groups'] = "Группы пользователей, которые могут создавать опрос:";
$MESS ['forum_template_vote_name'] = "Опросы для форумов";
?>