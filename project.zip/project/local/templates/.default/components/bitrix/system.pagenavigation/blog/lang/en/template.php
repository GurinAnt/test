<?
$MESS["nav_prev"] = "Prev.";
$MESS["nav_next"] = "Next";
$MESS["nav_paged"] = "Paged";
$MESS["nav_all"] = "All";
$MESS["pages"]="Pages:";
?>