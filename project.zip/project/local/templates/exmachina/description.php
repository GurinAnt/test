<?
$arTemplate = array (
  'NAME' => 'Шаблон Ex Machina',
  'DESCRIPTION' => 'Шаблон для сайта Ex Machina',
  'SORT' => '',
  'TYPE' => '',
);
?>