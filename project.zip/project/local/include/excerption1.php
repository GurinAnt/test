<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("");
?><h3>Mauris vulputate dolor sit amet</h3>
<p>
	<a href="#">Donec leo, vivamus fermentum nibh in augue praesent a lacus at urna congue rutrum.</a>
</p><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>