<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("");
?><a href="#" class="button">More Collections</a>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>