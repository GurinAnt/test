<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("");
?><li><a href="#"><img src="<?=SITE_TEMPLATE_PATH?>/images/pics07.jpg" alt=""></a></li>
								<li><a href="#"><img src="<?=SITE_TEMPLATE_PATH?>/images/pics08.jpg" alt=""></a></li>
								<li><a href="#"><img src="<?=SITE_TEMPLATE_PATH?>/images/pics09.jpg" alt=""></a></li>
								<li><a href="#"><img src="<?=SITE_TEMPLATE_PATH?>/images/pics10.jpg" alt=""></a></li>
								<li><a href="#"><img src="<?=SITE_TEMPLATE_PATH?>/images/pics11.jpg" alt=""></a></li>
								<li><a href="#"><img src="<?=SITE_TEMPLATE_PATH?>/images/pics12.jpg" alt=""></a></li>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>