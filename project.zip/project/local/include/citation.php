<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("");
?>“&nbsp;&nbsp;Donec leo, vivamus ullamcorper fermentum nibh in augue pulvinar ullamcorper metus praesent a lacus at urna congue ullamcorper rutrum.&nbsp;&nbsp;”<br>
 <br>
 <strong>–&nbsp;&nbsp;John Smith</strong><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>