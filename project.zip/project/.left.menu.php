<?
$aMenuLinks = Array(
	Array(
		"", 
		"/sidebar/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Feugiat Tempus", 
		"/sidebar/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Nulla luctus eleifend", 
		"/sidebar/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>