<?
$sSectionName = "/news";
$arDirProperties = array(
   "type_sidebar" => "H"
);
?>