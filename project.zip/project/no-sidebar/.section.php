<?
$sSectionName = "no-sidebar";
$arDirProperties = array(
   "type_sidebar" => "N"
);
?>