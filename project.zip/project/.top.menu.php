<?
$aMenuLinks = Array(
	Array(
		"Homepage", 
		"/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Left sidebar", 
		"/left-sidebar/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Right sidebar", 
		"/right-sidebar/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"No sidebar", 
		"/no-sidebar/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>