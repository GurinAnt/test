<?
$sSectionName = "right-sidebar";
$arDirProperties = array(
   "type_sidebar" => "R"
);
?>